export class Role{
    constructor(public id:number,public authority:string){

    }
}