import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from 'src/Model/Employee';
import { AuthenticationService } from '../Service/authentication.service';
import { UserService } from '../Service/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  emp: Employee = new Employee();
  constructor(private service: UserService,
    private router: Router, private authentication: AuthenticationService) { }

  ngOnInit(): void {
  }

  performLogin() {
    console.log("Username is ", this.emp.email);
    console.log("Password is ", this.emp.password);
    this.service.checkUser(this.emp).subscribe(response => {
      let jwt = response.jwt;
      console.log(jwt)
      this.authentication.login(jwt);
      this.router.navigate(['room']);
    });

  }
}
