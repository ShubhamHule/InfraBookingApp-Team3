import { Component, OnInit } from '@angular/core';
import { Room } from 'src/Model/Room';
import { RoomService } from '../Service/room.service';

@Component({
  selector: 'app-room',
  templateUrl: './room.component.html',
  styleUrls: ['./room.component.css']
})
export class RoomComponent implements OnInit {

  rooms: Room[] = [];
  outputMsg: string = "";
  constructor(private service: RoomService) {
    this.loadRooms();
  }

  loadRooms() {
    this.service.getRooms().subscribe(success => this.rooms = success, error => this.outputMsg = error.status + " " + error.message);
  }

  ngOnInit(): void {
  }

}
