import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Employee } from 'src/Model/Employee';
import { LoginResponse } from 'src/Model/LoginResponse';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }

  checkUser(emp: Employee) {
    return this.http.post<LoginResponse>('http://localhost:9999/user/authenticate', emp);
  }
}
