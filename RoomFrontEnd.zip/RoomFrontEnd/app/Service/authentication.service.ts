import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor() { }

  isLoggedIn(): boolean {
    let jwt = sessionStorage.getItem('jwt');
    return jwt != null;
  }

  getToken() {
    return sessionStorage.getItem('jwt');
  }

  logout() {
    sessionStorage.removeItem('jwt');
  }

  login(jwt: string) {
    sessionStorage.setItem('jwt', jwt);
  }
}
