export class Room {
    constructor(public id: number = 0, public code: string = "", public capacity: number = 0) {

    }
}