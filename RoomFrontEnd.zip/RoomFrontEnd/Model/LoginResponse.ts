export class LoginResponse {
    jwt: string = "";
}